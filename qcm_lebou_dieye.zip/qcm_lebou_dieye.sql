-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  lun. 15 juin 2020 à 02:57
-- Version du serveur :  10.1.35-MariaDB
-- Version de PHP :  7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `qcm_lebou_dieye`
--

-- --------------------------------------------------------

--
-- Structure de la table `evolution`
--

CREATE TABLE `evolution` (
  `ID` int(11) NOT NULL,
  `LOGIN` varchar(25) NOT NULL,
  `SCOREFINAL` int(11) DEFAULT NULL,
  `POURCENTAGE` int(11) DEFAULT NULL,
  `DATE` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `nombre`
--

CREATE TABLE `nombre` (
  `NBRPTS` int(7) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `nombre`
--

INSERT INTO `nombre` (`NBRPTS`) VALUES
(7);

-- --------------------------------------------------------

--
-- Structure de la table `questions`
--

CREATE TABLE `questions` (
  `ID_QUEST` int(11) NOT NULL,
  `QUESTION` varchar(255) DEFAULT NULL,
  `TYPE` varchar(15) DEFAULT NULL,
  `NBRPTS` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `questions`
--

INSERT INTO `questions` (`ID_QUEST`, `QUESTION`, `TYPE`, `NBRPTS`) VALUES
(2, ':knk kmkl Ã¹!ln', 'Type commentair', 6),
(3, 'Quelle est la premiere question de cette liste ???', 'Type commentair', 6),
(4, 'BHNJL.J/LBVKJ', 'Choix Multiple', 6),
(5, 'knnkmjbb ', 'Choix Unique', 5),
(6, 'knnkmjbb ', 'Choix Unique', 5),
(9, 'quelle', 'Type commentair', 3),
(10, 'aaaaa', 'Choix Multiple', 10),
(11, 'bbbbb', 'Choix Unique', 10),
(12, 'assassaa', 'Choix Unique', 5),
(14, 'ddddddd', 'Choix Multiple', 5),
(15, 'ccccccc', 'Choix Unique', 9),
(16, 'zzzzzzzzzz', 'Type commentair', 5),
(17, 'zzzzzzzzzz11111', 'Type commentair', 5),
(19, 'Quel est l\'OS le plus utilisÃ© au monde ????', 'Choix Unique', 8),
(20, 'Juste donner une appreciation Ã  vos formateurs !!!', 'Type commentair', 8);

-- --------------------------------------------------------

--
-- Structure de la table `reponses`
--

CREATE TABLE `reponses` (
  `ID_RESP` int(10) NOT NULL,
  `ID_QUEST` int(11) NOT NULL,
  `REPONSE` text,
  `VALEUR` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponses`
--

INSERT INTO `reponses` (`ID_RESP`, `ID_QUEST`, `REPONSE`, `VALEUR`) VALUES
(2, 4, 'assas', 'False'),
(3, 4, 'assaassas', 'True'),
(4, 5, ';jlbbbm:k', 'True'),
(5, 5, ';jlbbbm:k', 'False'),
(6, 5, 'm:nb m!kb', 'False'),
(7, 6, 'qaaaa', 'False'),
(8, 6, 'm:nb m!kb', 'True'),
(9, 6, 'm:nb m!kb', 'False'),
(14, 9, 'Veuillez e', 'NONE'),
(15, 10, 'aaaaa', 'False'),
(16, 10, 'aaaaa', 'True'),
(17, 10, 'aaaaa', 'False'),
(18, 11, 'bbbbb', 'False'),
(19, 12, 'assasasas', 'False'),
(20, 12, 'assaassas', 'True'),
(22, 14, 'ddddddd', 'True'),
(23, 14, 'ddddddd', 'True'),
(24, 14, 'ddddddd', 'False'),
(46, 15, 'cccccc1', 'False'),
(47, 15, 'cccccc2', 'True'),
(48, 15, 'cccccc3', 'False'),
(53, 16, 'Veuillez e', 'NONE'),
(54, 17, 'Veuillez ecrire la reponse la plus simple.', 'NONE'),
(71, 19, 'Windows', 'True'),
(72, 19, 'Linux', 'False'),
(73, 19, 'Mac', 'False'),
(74, 20, 'Ils sont tous formidables et plus que excellents !!!', 'NONE'),
(76, 3, 'Celle ci !!!', 'NONE');

-- --------------------------------------------------------

--
-- Structure de la table `trouver`
--

CREATE TABLE `trouver` (
  `ID_QUEST` int(11) NOT NULL,
  `LOGIN` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `LOGIN` varchar(25) NOT NULL,
  `PASSWORD` varchar(20) DEFAULT NULL,
  `PRENOM` varchar(25) DEFAULT NULL,
  `NOM` varchar(15) DEFAULT NULL,
  `TYPE` varchar(15) DEFAULT NULL,
  `MEILLEUR_SCORE` int(11) DEFAULT NULL,
  `PHOTO` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`LOGIN`, `PASSWORD`, `PRENOM`, `NOM`, `TYPE`, `MEILLEUR_SCORE`, `PHOTO`) VALUES
('aa', 'aa', 'aa', 'aa', 'admin', 0, 'aa.jpg'),
('aaaajljk1bbb', 'aa', 'jh', 'aa', 'admin', 0, 'aaaajljk1bbb.jpg'),
('aaaajljk1bbbs', 'aa', 'ss', 'aa', 'admin', 0, 'aaaajljk1bbbs.jpg'),
('aaaajljk1bbbsx', 'aa', 'xxx', 'aa', 'admin', 0, 'aaaajljk1bbbsx.jpg'),
('admin', 'admin', 'Amadou', 'NDIAYE', 'admin', 0, 'profile2.jpg'),
('Aly', 'passer', 'Aly', 'Diallo', 'joueur', 0, 'Aly.png'),
('awa', 'passer', 'Awa', 'NDIAYE', 'joueur', 0, 'awa.jpg'),
('dsd', 'aa', 'sdds', 'dsd', 'admin', 0, 'dsd.jpg'),
('dsds', 'aa', 'sddd', 'sddd', 'admin', 0, 'dsds.jpg'),
('fff', 'fff', 'fff', 'ff', 'admin', 0, 'fff.jpg'),
('joueur', 'joueur', 'Salymata', 'DIEYE', 'joueur', 15, 'profile2.png'),
('joueur1', 'joueur1', 'joueur1', 'joueur1', 'joueur', 0, 'joueur1.png'),
('joueur2', 'joueur2', 'joueur2', 'joueur2', 'joueur', 0, 'joueur2.png'),
('joueur3', 'joueur3', 'joueur3', 'joueur3', 'joueur', 0, 'joueur3.png'),
('joueur4', 'joueur4', 'joueur4', 'joueur4', 'joueur', 0, 'joueur4.png'),
('joueur5', 'joueur5', 'joueur5', 'joueur5', 'joueur', 0, 'joueur5.png'),
('knknln', 'pppp', 'nknlknlkn', 'jbj', 'admin', 0, 'knknln.jpg'),
('lamine', 'passer', 'Lamine', 'Ndiaye1', 'joueur', 0, 'lamine.png'),
('lebz', 'lebz', 'lebz', 'lebz', 'admin', 0, 'lebz.jpg'),
('lebz1', 'lebz1', 'lebz12', 'lebz1', 'joueur', 0, 'lebz1.png'),
('lebz2', 'lebz2', 'lebz2', 'lebz2', 'admin', 0, 'lebz2.jpg'),
('lebzo', 'lebzo', 'lebzo', 'lebzo', 'admin', 0, 'lebzo.jpg'),
('Lebzooo', 'Lebzooo', 'Lebzooo', 'Lebzooo', 'admin', 0, 'Lebzooo.png'),
('Lebzooo4', 'Lebzooo4', 'Lebzooo4', 'Lebzooo4', 'admin', 0, 'Lebzooo4.png'),
('Saliou', 'passer', 'Saliou', 'NDIAYE', 'admin', 0, 'Saliou.png'),
('sd', 'sdsd', 'ssd', 'sd', 'admin', 0, 'sd.jpg'),
('sddd', 'ddd', 'sd', 'sddss', 'admin', 0, 'sddd.jpg'),
('sdds', 'aa', 'sddds', 'sddds', 'admin', 0, 'sdds.jpg'),
('ss', 'ss', 'ss', 'sss', 'admin', 0, 'ss.jpg'),
('sss', 'ss', 'ss', 'ss', 'admin', 0, 'sss.jpg'),
('ssss', 'sss', 'ssss', 'sss', 'admin', 0, 'ssss.jpg'),
('ssssssss', 'ss', 'sss', 'ss', 'admin', 0, 'ssssssss.jpg'),
('zz', 'aa', 'zz', 'zz', 'admin', 0, 'zz.jpg');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `evolution`
--
ALTER TABLE `evolution`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `FK_CONCERNER` (`LOGIN`);

--
-- Index pour la table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`ID_QUEST`);

--
-- Index pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD PRIMARY KEY (`ID_RESP`),
  ADD KEY `FK_CORRESPONDRE` (`ID_QUEST`);

--
-- Index pour la table `trouver`
--
ALTER TABLE `trouver`
  ADD PRIMARY KEY (`ID_QUEST`,`LOGIN`),
  ADD KEY `FK_TROUVER` (`LOGIN`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`LOGIN`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `reponses`
--
ALTER TABLE `reponses`
  MODIFY `ID_RESP` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `evolution`
--
ALTER TABLE `evolution`
  ADD CONSTRAINT `FK_CONCERNER` FOREIGN KEY (`LOGIN`) REFERENCES `users` (`LOGIN`);

--
-- Contraintes pour la table `reponses`
--
ALTER TABLE `reponses`
  ADD CONSTRAINT `FK_CORRESPONDRE` FOREIGN KEY (`ID_QUEST`) REFERENCES `questions` (`ID_QUEST`);

--
-- Contraintes pour la table `trouver`
--
ALTER TABLE `trouver`
  ADD CONSTRAINT `FK_TROUVER` FOREIGN KEY (`LOGIN`) REFERENCES `users` (`LOGIN`),
  ADD CONSTRAINT `FK_TROUVER2` FOREIGN KEY (`ID_QUEST`) REFERENCES `questions` (`ID_QUEST`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
