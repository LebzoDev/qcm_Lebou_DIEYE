<?php

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=quizz_lebou_dieye', 'root', '', array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
}
catch(Exception $erreur)
{
        die('Erreur : '.$erreur->getMessage());
}
?>